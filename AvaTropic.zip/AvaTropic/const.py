EVENT_TITLE = 35
BAN_PRIVILEGIES = 5
NAME_MAX_LENGTH = 20
NAME_MIN_LENGHT = 2
MAX_ROOM_NAME = 13
PRICE_RENAME = 50
LOCATION_LIMIT = 35
SEND_SYSTEM_MESSAGE = 5
EVENT_DESCRIPTION = 72
TECHNICAL_WORKING = False

port101xp = 8123
host101xp = "178.248.237.132"

wearing = ["club", "official",
               "swimwear", "underdress"]

room_items = [{'tpid': 'LBjule21_wall', 'gtp': '', 'd': 3, 'lid': 1, 'x': 0.0, 'y': 0.0, 'z': 0.0, 'bid': '', 'lrd': 0},
             {'tpid': 'LBjule21_wall', 'gtp': 'wllgrfft3', 'd': 5, 'lid': 2, 'x': 13.0, 'y': 0.0, 'z': 0.0, 'bid': '', 'lrd': 0},
             {'tpid': 'LBjule21_floor', 'd': 5, 'lid': 3, 'x': 0.0, 'y': 0.0, 'z': 0.0}, {'tpid': 'bth_tropics_door', 'd': 3, 'lid': 4, 'x': 3.0, 'y': 0.0, 'z': 0.0, 'rid': 'outside'},
             {'tpid': 'bth_tropics_door', 'd': 3, 'lid': 5, 'x': 10.0, 'y': 0.0, 'z': 0.0, 'rid': None}, {'tpid': 'bth_tropics_door', 'd': 5, 'lid': 6, 'x': 13.0, 'y': 8.0, 'z': 0.0, 'rid': None},
             {'tpid': 'DoubleArmchair4', 'd': 3, 'jid': None, 'lid': 11, 'x': 3.0, 'y': 5.0, 'z': 0.0, 'jiid': None}, {'tpid': 'table1', 'd': 5, 'lid': 8, 'x': 3.0, 'y': 8.0, 'z': 0.0},
             {'tpid': 'Hawaii_Sofa', 'd': 5, 'jid': None, 'lid': 13, 'x': 6.0, 'y': 7.0, 'z': 0.0, 'jiid': None}, {'tpid': 'window7', 'd': 5, 'lid': 7, 'x': 13.0, 'y': 1.34, 'z': 1.0},
             {'tpid': 'LBgrdtn21_wardrobe1', 'd': 5, 'lid': 9, 'x': 12.0, 'y': 6.0, 'z': 0.0}, {'tpid': 'LBjule21_lamp_floor', 'd': 5, 'lid': 10, 'x': 6.3, 'y': 5.3, 'z': 0.0},
             {'tpid': 'pictureIris', 'd': 3, 'lid': 12, 'x': 6.75, 'y': 0.0, 'z': 2.0}]
