import redis
import aioredis

r = redis.Redis(decode_responses=True)
promocode = " Test" 
r.sadd(f"offers:promocodes", promocode) 
r.set(f"offers:promocodes:{promocode}:promocode_title", "Test") 
r.set(f"offers:promocodes:{promocode}:promocode_item", "res:gld:1111111")  
print("Start promo_code.db") 
 