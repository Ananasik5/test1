import redis, time
import aiohttp_jinja2
import jinja2, hashlib
from aiohttp import web

conf = {
    'sums': [149],
    'projectName': 'AvaBuffing',
    'projectId': 'Enter projectId',
    'publicKey': 'Enter publicKey',
    'secret-key': 'Enter Secret Key'
} #Data with UnitPay

class Web:
    def __init__(self):
        self.app = web.Application()

    async def index(self, req, context={'url': False}):
        return aiohttp_jinja2.render_template('index.html', req, context=context)

    async def mobile(self, req, context={}):
        data = req.query_string
        if data.split("mobileId=")[1] and\
                data.split("mobileId=")[1].isdigit():
            uid = data.split("mobileId=")[1]
            signaturee = [f'premium_{uid}', f'Покупка премиума на {conf["projectName"]}', '149', conf['secret-key']]
            signature = "{up}".join(signaturee).encode()
            signature = hashlib.sha256(signature).hexdigest()
            url = "https://unitpay.money/pay/"+conf['publicKey']+"/card?account="+signaturee[0]+"&desc="+signaturee[1]+"&sum="+signaturee[2]+"&signature="+signature
            if "amp;" in url:
                url = ''.join(url.split("amp;"))
            context['url'] = url
        return aiohttp_jinja2.render_template('index.html', req, context=context)

    async def pay(self, req, context={}):
        data = req.query_string
        if not data:
            return False
        sum = 0
        method = None
        account = None
        new_sign = []
        old_sign = None
        for item in "=".join(data.split("=")).split("&params"):
            if item.split("=")[0] not in ['[sign]', '[signature]',
                                          'sign', 'signature']:
                new_sign.append(item.split("=")[1])
            if 'method' in item:
                method = item.split("=")[1]
            item = item.split("=")
            items = item[1]
            if item[0] == '[signature]':
                old_sign = items
            elif item[0] == '[sum]':
                sum = int(items)
            elif item[0] == '[projectId]':
                if items != conf['projectId']:
                    return
            elif item[0] == '[account]':
                account = items
        new_sign.append(conf['secret-key'])
        signature = "{up}".join(new_sign).encode()
        signature = hashlib.sha256(signature).hexdigest()
        if signature == old_sign:
            if method == 'pay':
                if "_" in account:
                    user_id = account.split("_")[1]
                    if sum == conf['sums'][0]:
                        self.add_premium(user_id)
        return web.json_response({"result": {"message": "Запрос успешно обработан"}})

    def add_premium(self, uid):
        days = int(time.time())+30*24*3600
        redis_server.set(f'uid:{uid}:premium', days)

    async def main(self):
        global redis_server
        self.app.add_routes(self.router())
        aiohttp_jinja2.setup(self.app, loader=jinja2.FileSystemLoader("index/templates"))
        redis_server = redis.Redis(decode_responses=True)
        runner = web.AppRunner(self.app)
        await runner.setup()
        site = web.TCPSite(runner, "0.0.0.0", 8080)
        await site.start()

    def router(self):
        return [
            web.get('/', self.index),
            web.get('/pay', self.pay),
            web.get('/mobile', self.mobile),
            web.static('/files', 'index/files'),
        ]
